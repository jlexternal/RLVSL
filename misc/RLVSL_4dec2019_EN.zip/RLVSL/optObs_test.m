% Test: Optimal observer behavior on generated experiments

test = struct;
n_obs   = 100;  % number of observers
alpha   = .2;   % learning rate
zeta    = 1;    % learning noise
r_sd    = 15;   % standard deviation of reward distribution
vs      = r_sd^2; % sampling variance (set equal to true variance of distribution)

% use gen_expe to generate setup data
for i = 1:n_obs
    test(i).expe = gen_expe_rlvsl(i);
end


nb = numel(test(1).expe) - 3;       % number of blocks
nt = numel(test(1).expe(1).blck);   % number of trials per block

% set up data structures
ests    = zeros(nb,nt,n_obs); % number of blocks X number of trials X number of observers
rews    = zeros(nb,nt,n_obs); % seen reward difference
vars    = zeros(nb,nt,n_obs); % posterior variances

% run optimal observer on each using TRANSFORMED reward distributions
for ib = 1:nb
    ests(ib,1,:) = 0;   % initialize 1st estimate of the mean value difference (in reality should approach 10)
    vars(ib,1,:) = 1e6; % iniitalize flat posterior variance
    
    % transform rewards
    mu_new  = 10;   % desired mean of distribution
    sig_new = 15;   % desired std of distribution
    a = sig_new/test(1).expe(1).cfg.sgen;       % slope of linear transformation aX+b
    b = mu_new - a*test(1).expe(1).cfg.mgen;    % intercept of linear transf. aX+b
    %           use repmat 
    
    % record estimates from KF (Q-val)
    
    % 1st choice is random (flat prior)
    blckobs = test(1).expe(ib).blck;
    for it = 2:nt
    
        k = vars(ib,it-1,:)./(vars(ib,it-1,:)+vs); % Kalman gain
        % update estimate
        ests(ib,it,:) = ests(ib,it-1,:)+(rt(ib,it-1,:)-mt(ib,it-1,:)).*kt.*(1+randn(1,1,ns)*zeta);
        % update variance
    
        % record reward distance (don't need responses)
    end
    
end

% plot KF trajectories

% for the correlation matrix, be sure to use 1 distance for the reward shown (i.e.
%   distance away from the center, since the fluctuations of good/bad answers will
%   create divergences)



