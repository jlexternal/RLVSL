% Integration of Reinforcement Learning and Structure Learning (alpha 2)
%
% This code is a second attempt at bringing together a model of reinforcement learning
% and structure learning decision process
%
% Jun Seok Lee - Dec 2019



%%  Generate experiments 

% call gen_expe_rlvsl multiple times to set the structure

