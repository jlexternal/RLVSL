function gen_expe_subj(subj)
%  GEN_EXPE_SUBJ  Generate and save experiment structure
%
%  Usage: GEN_EXPE_SUBJ(subj)
%
%  where subj is the subject number
%
%  The function plots condition-wise scores for the reference learning model,
%  corresponding to a comparative reinforcement-learning model with a learning
%  rate of 0.5. Scores correspond to mean-wise relative values (chosen minus
%  unchosen). The generated blocks have *not* been constrained w.r.t. model-
%  predicted scores.
%
%  Valentin Wyart <valentin.wyart@ens.fr> - Jan. 2016

% initialize random number generator
RandStream.setGlobalStream(RandStream('mt19937ar','Seed','shuffle'));

% generate experiment structure
expe = gen_expe(subj);

% save experiment structure
mkdir(sprintf('./Data/S%02d',subj));
filename = sprintf('./Data/S%02d/RLVAR_S%02d_expe.mat',subj,subj);
save(filename,'expe');

% compute condition-wise score
s_vm = zeros(2,2,2);
for i = 5:12
    out = sim_model_ref(expe,i,1);
    i1 = out.blck.cfg.tau_samp;
    i2 = out.blck.cfg.feedback;
    i3 = out.blck.cfg.anticorr+1;
    s_vm(i1,i2,i3) = out.s_vm;
end

% plot condition-wise score
figure('Color','white');
subplot(1,2,1);
hold on
bar(s_vm(:,:,1));
xlim(xlim);
ylim([0,25]);
hold off
set(gca,'Box','off','XTick',[1,2]);
xlabel('tau(samp)');
ylabel('mean-wise score');
legend({'fb = 1','fb = 2'},'Location','NorthWest');
legend boxoff
title('uncorrelated');
subplot(1,2,2);
hold on
bar(s_vm(:,:,2));
xlim(xlim);
ylim([0,25]);
hold off
set(gca,'Box','off','XTick',[1,2]);
xlabel('tau(samp)');
title('anti-correlated');

end