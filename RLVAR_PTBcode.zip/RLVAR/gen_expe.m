function [expe] = gen_expe(subj)
%  GEN_EXPE  Generate experiment structure
%
%  Usage: [expe] = GEN_EXPE(subj)
%
%  where subj is the subject number
%        expe is the generated experiment structure
%
%  The experiment structure expe contains the following fields:
%    * cfg   - configuration structure
%    * type  - block type ('training' or 'test')
%    * vm    - bandit means, 2-by-n(trials) array
%    * vs    - bandit samples, 2-by-n(trials) array
%    * shape - bandit shapes, 2-by-1 array
%    * color - bandit colors, 2-by-1 array
%
%  The configuration structure cfg contains the three experimental factors:
%    * tau_samp - bandit sampling stability
%    * anticorr - bandit anti-correlation? (true or false)
%    * feedback - bandit feedback (1:chosen or 2:chosen+unchosen)
%
%  The parity of subject number determines the order in which the training
%  blocks are carried out. Odd-numbered subjects start with anticorrelated
%  bandits, whereas even-numbered subjects start with uncorrelated ones.
%
%  The experiment contains 4 training blocks, followed by 8 test blocks. Each
%  training block contains 48 trials, each test block 96 trials. Shapes and
%  colors are changed across blocks.
%
%  Valentin Wyart <valentin.wyart@ens.fr> - Jan. 2016

% check input arguments
if nargin < 1
    error('Missing subject number!');
end

% add toolboxes to path
addpath('./Toolboxes/Rand');

% initialize random number generator
RandStream.setGlobalStream(RandStream('mt19937ar','Seed','shuffle'));

fprintf('\n');
fprintf('GENERATING EXPERIMENT\n');
fprintf('\n');

expe = [];

% set bandit fluctuation parameters
% defaults: epimin = 8, epimax = 32, tau_fluc = 3
% this produces exponentially-distributed episodes of 16 trials on average
cfg          = [];
cfg.epimin   = 8; % minimum episode length
cfg.epimax   = 32; % maximum episode length
cfg.tau_fluc = 3; % bandit fluctuation stability

% set configuration parameters for training blocks
% defaults: 3 episodes (48 trials), tau_samp = 3
cfg_trn          = cfg;
cfg_trn.nepi     = 3; % number of episodes
cfg_trn.ntrl     = 48; % number of trials
cfg_trn.tau_samp = 3; % bandit sampling stability

% generate training blocks
anticorr_trn = mod(subj,2) == [1,1,0,0];
for i = 1:4
    fprintf('GENERATING TRAINING BLOCK %d/4\n',i);
    % set condition for training block
    cfg_trn.anticorr = anticorr_trn(i); % 1:anticorrelated, 0:uncorrelated
    cfg_trn.feedback = 1+mod(i,2); % 1:chosen, 2:chosen+unchosen
    % generate training block with lower generation precision
    blck = gen_blck(setfield(cfg_trn,'pgen',0.05));
    % store configuration parameters
    expe(i).cfg = cfg_trn;
    expe(i).type = 'training';
    % store bandit means
    expe(i).vm(1,:) = blck.pp;
    expe(i).vm(2,:) = blck.qq;
    % store bandit samples
    expe(i).vs(1,:) = blck.ps;
    expe(i).vs(2,:) = blck.qs;
    % store bandit positions
    expe(i).pos = blck.pos;
    fprintf('\n');
end

% create factor matrix
f = [ ...
    1 1 1 1 2 2 2 2; ... % factor #1 (2 levels)
    1 1 2 2 1 1 2 2; ... % factor #2 (2 levels)
    1 2 1 2 1 2 1 2];    % factor #3 (2 levels)
% shuffle factor matrix
while true
    f = f(:,randperm(8));
    if ...
            all(sum(f(:,1:2) == 1,2) == 1) && ...
            all(sum(f(:,3:4) == 1,2) == 1) && ...
            all(sum(f(:,5:6) == 1,2) == 1) && ...
            all(sum(f(:,7:8) == 1,2) == 1) && ...
            sum(f(1,f(2,:) == 1 & 1:8 <= 4)) == 3 && ...
            sum(f(1,f(2,:) == 1 & 1:8 >= 5)) == 3
        break
    end
end

% set configuration parameters for test blocks
% defaults: 6 episodes (96 trials)
cfg_tst      = cfg;
cfg_tst.nepi = 6;
cfg_tst.ntrl = 96;

% generate test blocks
% defaults: tau_samp = 1 or 2
tau_samp_tst = [1,2]; % level #1:more variable, level #2:less variable
anticorr_tst = [0,1]; % level #1:uncorrelated, level #2:anticorrelated
feedback_tst = [2,1]; % level #1:chosen+unchosen, level #2:chosen
for i = 1:8
    fprintf('GENERATING TEST BLOCK %d/8\n',i);
    % set condition for test block
    cfg_tst.tau_samp = tau_samp_tst(f(1,i));
    cfg_tst.anticorr = anticorr_tst(f(2,i));
    cfg_tst.feedback = feedback_tst(f(3,i));
    while true
        % generate test block
        blck = gen_blck(cfg_tst);
        % store configuration parameters
        expe(i+4).cfg = cfg_tst;
        expe(i+4).type = 'test';
        % store bandit means
        expe(i+4).vm(1,:) = blck.pp;
        expe(i+4).vm(2,:) = blck.qq;
        % store bandit samples
        expe(i+4).vs(1,:) = blck.ps;
        expe(i+4).vs(2,:) = blck.qs;
        % store bandit positions
        expe(i+4).pos = blck.pos;
        % check impact of 1st response
        s_vm = [ ...
            getfield(sim_model_ref(expe,i+4,1),'s_vm'), ...
            getfield(sim_model_ref(expe,i+4,2),'s_vm')];
        if abs(diff(s_vm)/sum(s_vm)) < 0.05
            break
        end
    end
    fprintf('\n');
end

% generate pairs of shape/color combinations
% shape = 1:circle, 2:triangle, 3:diamond, 4:pentagon, 5:star, 6:plus
% color = 1:yellow, 2:orange, 3:red, 4:purple, 5:blue, 6:green
fprintf('GENERATING PAIRS OF SHAPE/COLOR COMBINATIONS\n');
while true
    % permute shape/color combinations
    % goal: pairs differ in both shape and color
    %       shape/color combinations are used only once in the experiment
    while true
        shape_lst = [randperm(6),randperm(6);randperm(6),randperm(6)];
        color_lst = [randperm(6),randperm(6);randperm(6),randperm(6)];
        if ...
                all(shape_lst(1,:) ~= shape_lst(2,:)) && ...
                all(color_lst(1,:) ~= color_lst(2,:)) && ...
                length(unique(6*(shape_lst(:)-1)+color_lst(:))) == 24
            break
        end
    end
    % permute pairs of shape/color combinations
    % goal: successive blocks never contain the same shape or color
    p = perms(1:6);
    for i1 = 1:size(p,1) % permutation for 1st half
        for i2 = 1:size(p,1) % permutation for 2nd half
            ishuf = [p(i1,:),6+p(i2,:)];
            shape_tmp = shape_lst(:,ishuf);
            color_tmp = color_lst(:,ishuf);
            found = true;
            for i = 1:6
                if ...
                        any(diff(ceil(find(shape_tmp(:) == i)/2)) == 1) || ...
                        any(diff(ceil(find(color_tmp(:) == i)/2)) == 1)
                    found = false;
                    break
                end
            end
            if found
                break
            end
        end
        if found
            break
        end
    end
    if found
        shape_lst = shape_tmp;
        color_lst = color_tmp;
        break
    end
end
% store bandit shape/color combinations
for i = 1:12
    expe(i).shape = shape_lst(:,i);
    expe(i).color = color_lst(:,i);
end
fprintf('\n');

end