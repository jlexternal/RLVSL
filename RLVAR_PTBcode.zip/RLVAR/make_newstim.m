function [img] = make_newstim(cfg)


carddmtr  = 240;
cardwdth = 8;
anglwdth = 8;
angl     = pi/8;
opctangl = 0.5;
opctbrdr = 0.25;

fxtndmtr = 24;
fxtncolr = [0,0,0];
fxtnwdth = 0;

lumifg   = 0.5;

% define function handles
fsmooth = @(x,r)r(1)+diff(r)./(1+99.^(-x)); % smoothing function
modzero = @(x,m)mod(x+m/2,m)-m/2; % zero-centered modulus

% set outer diameter
outrdmtr = carddmtr+4*anglwdth;

% set polar coordinates
[x,y] = meshgrid([1:outrdmtr]-(outrdmtr+1)/2);
r = sqrt(x.^2+y.^2);
t = -atan2(y,x);

patchfg = ones([outrdmtr,outrdmtr,3])*lumifg;


% draw card foreground
colrfg = [1,lumifg,lumifg*2-1;lumifg*2-1,lumifg,1];
% % % if flipfg
% % %     colrfg = flipud(colrfg);
% % % end

colrfg = [1,1,1;1,1,1]*0.25;

% draw card angle
if ~isempty(angl)
    
    u = sin(angl)*x+cos(angl)*y;
    patchtp = ones(outrdmtr,outrdmtr);
    patchtp = min(patchtp,fsmooth(u+anglwdth/2,[0,1]));
    patchtp = min(patchtp,fsmooth(u-anglwdth/2,[1,0]));
    patchtp = min(patchtp,fsmooth(r-carddmtr/4+2,[1,0]));
    patchtp = patchtp*opctangl;
    patchfg = bsxfun(@plus, ...
        bsxfun(@times,patchfg,1-patchtp), ...
        bsxfun(@times,reshape(colrfg(1,:),1,1,[]),patchtp));
    
    u = sin(angl+pi/2)*x+cos(angl+pi/2)*y;
    patchtp = ones(outrdmtr,outrdmtr);
    patchtp = min(patchtp,fsmooth(u+anglwdth/2,[0,1]));
    patchtp = min(patchtp,fsmooth(u-anglwdth/2,[1,0]));
    patchtp = min(patchtp,fsmooth(r-carddmtr/4+2,[1,0]));
    patchtp = patchtp*opctangl;
    patchfg = bsxfun(@plus, ...
        bsxfun(@times,patchfg,1-patchtp), ...
        bsxfun(@times,reshape(colrfg(2,:),1,1,[]),patchtp));
    
end



% % draw card angle
% if ~isempty(angl)
%     u = sin(angl)*x+cos(angl)*y;
%     patchtp = ones(outrdmtr,outrdmtr);
%     patchtp = min(patchtp,fsmooth(u+anglwdth/2,[0,1]));
%     patchtp = min(patchtp,fsmooth(u-anglwdth/2,[1,0]));
%     patchtp = min(patchtp,fsmooth(r-carddmtr/2+2,[1,0]));
%     patchtp = patchtp*opctangl;
%     patchfg = bsxfun(@times,patchfg,1-patchtp);
% end

% draw card border
patchtp = ones(outrdmtr,outrdmtr);
patchtp = min(patchtp,fsmooth(r-carddmtr/2+cardwdth+2,[0,1]));
patchtp = min(patchtp,fsmooth(r-carddmtr/2+2,[1,0]));
patchtp = patchtp*opctbrdr;
patchfg = bsxfun(@times,patchfg,1-patchtp);

% draw fixation point
if fxtndmtr > 0
    patchtp = ones(outrdmtr,outrdmtr);
    patchtp = min(patchtp,fsmooth(r-fxtndmtr/2,[1,0]));
    patchfg = bsxfun(@plus, ...
        bsxfun(@times,patchfg,1-patchtp), ...
        bsxfun(@times,reshape(fxtncolr,1,1,[]),patchtp));
    if fxtnwdth > 0
        patchtp = ones(outrdmtr,outrdmtr);
        patchtp = min(patchtp,fsmooth(r-fxtndmtr/2-2*fxtnwdth,[0,1]));
        patchtp = min(patchtp,fsmooth(r-fxtndmtr/2-3*fxtnwdth,[1,0]));
        patchfg = bsxfun(@times,patchfg,1-patchtp);
    end
end


% return image
img = patchfg;


end