function [data] = gen_data(cfg)
%  GEN_DATA  Generate test data to explore task parameters
%
%  Usage: [data] = GEN_DATA(cfg)
%
%  where cfg is a configuration structure
%        data is the resulting test data structure
%
%  The configuration structure cfg contains the following fields:
%    * epimin   - minimum episode length
%    * epimax   - maximum episode length
%    * ngen     - number of episodes to be generated (optional)
%    * tau_fluc - bandit fluctuation stability
%    * tau_samp - bandit sampling stability
%    * anticorr - bandit anti-correlation? (true or false)
%    * alpha    - scaling factor (optional)
%
%  When bandits are anti-correlated, the range of values that they can take is
%  scaled such that the difficulty is matched with the condition in which they
%  are not correlated. This behavior is overridden when alpha is provided in
%  the configuration structure.
%
%  Valentin Wyart <valentin.wyart@ens.fr> - Jan. 2016

% check configuration structure
if ~all(isfield(cfg,{'epimin','epimax','tau_fluc','tau_samp','anticorr'}))
    error('Incomplete configuration structure!');
end
if ~isfield(cfg,'ngen')
    cfg.ngen = 1e4; % default: 10,000 episodes to be generated
end
if ~isfield(cfg,'alpha')
    cfg.alpha = []; % default: estimate scaling factor on-the-fly
end

% get configuration parameters
epimin   = cfg.epimin; % minimum episode length
epimax   = cfg.epimax; % maximum episode length
ngen     = cfg.ngen; % number of episodes to be generated (optional)
tau_fluc = cfg.tau_fluc; % bandit fluctuation stability
tau_samp = cfg.tau_samp; % bandit sampling stability
anticorr = cfg.anticorr; % bandit anti-correlation? (true or false)
alpha    = cfg.alpha; % scaling factor (optional)

data = [];

% define bandit sampling function
get_pr = @(p,t)betarnd(1+p*exp(t),1+(1-p)*exp(t));

% generate episodes
fprintf('generating episodes...\n');
pr_all = cell(ngen,1);
pr = zeros(1,epimax+2);
for i = 1:ngen
    while true
        pr(:) = 0;
        pr(1) = get_pr(0.5,tau_fluc);
        if pr(1) < 0.5
            pr(1) = 1-pr(1);
        end
        for j = 2:epimax+2
            pr(j) = get_pr(pr(j-1),tau_fluc);
            if pr(j) < 0.5
                break
            end
        end
        epilen = j-1;
        if epilen >= epimin && epilen <= epimax
            break
        end
    end
    pr_all{i} = pr(1:j-1);
end

% generate bandits
fprintf('generating bandits...\n');
n = cellfun(@length,pr_all);
pp = zeros(1,sum(n)); igen_pp = randperm(ngen); j_pp = 0;
qq = zeros(1,sum(n)); igen_qq = randperm(ngen); j_qq = 0;
for i = 1:ngen
    k_pp = j_pp+(1:n(igen_pp(i)));
    k_qq = j_qq+(1:n(igen_qq(i)));
    if mod(i,2) == 0
        pp(k_pp) = 1-pr_all{igen_pp(i)};
        qq(k_qq) = 1-pr_all{igen_qq(i)};
    else
        pp(k_pp) = pr_all{igen_pp(i)};
        qq(k_qq) = pr_all{igen_qq(i)};
    end
    j_pp = j_pp+n(igen_pp(i));
    j_qq = j_qq+n(igen_qq(i));
end
% compute average difference between two uncorrelated bandits
df_avg = mean(abs(pp-qq));
% compute average difference between two anti-correlated bandits
df_cor = mean(abs(pp*2-1));

if anticorr
    % imply second bandit from first bandit
    qq = 1-pp;
    % rescale bandits to control inter-bandit distance
    if isempty(alpha)
        % estimate scaling factor on-the-fly
        alpha = df_avg/df_cor;
        fprintf('  => scaling factor estimate: %.3f\n',alpha);
    end
    pp = (pp-0.5)*alpha+0.5;
    qq = (qq-0.5)*alpha+0.5;
end

% sample bandits
fprintf('sampling bandits...\n');
ps = get_pr(pp,tau_samp);
qs = get_pr(qq,tau_samp);

% add bandits to block structure
data.pp = pp*100;
data.qq = qq*100;
data.ps = min(max(round(ps*100),1),99);
data.qs = min(max(round(qs*100),1),99);

end