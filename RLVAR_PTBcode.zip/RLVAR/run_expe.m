function [expe,aborted,errmsg] = run_expe(subj,syncflip,trackeye)

% check input arguments
if nargin < 3
    trackeye = false;
end
if nargin < 2
    syncflip = true;
end
if nargin < 1
    error('Missing subject number!');
end

% create header
hdr = [];
hdr.subj = subj;
hdr.date = datestr(now,'yyyymmdd-HHMM');

% load experiment structure
filename = sprintf('./Data/S%02d/RLVAR_S%02d_expe.mat',subj,subj);
% filename = strcat(pwd,'\Data\RLVAR_S0',num2str(subj),'_expe.mat'); 
if ~exist(filename,'file')
    error('Missing experiment file!');
end
load(filename,'expe');
expe(1).hdr = hdr;

% define output arguments
aborted = false; % aborted prematurely?
errmsg = []; % error message

% set screen parameters
iscr = 0; % screen index
res  = []; % screen resolution
fps  = []; % screen refresh rate
ppd  = 40; % number of screen pixels per degree of visual angle

% set list of color-wise R/G/B values
color_rgb = [ ...
    255,255,000; ... % yellow
    255,130,000; ... % orange
    255,000,000; ... % red
    170,000,170; ... % purple
    000,000,255; ... % blue
    035,220,000; ... % green
    ]/255;
color_opa = 2/3; % color opacity

% set stimulation parameters
lumibg    = 128/255; % background luminance
fixtn_siz = 0.3*ppd; % fixation point size
shape_siz = 4.0*ppd; % shape size
shape_off = 4.0*ppd; % shape offset
fbtxt_fac = 2.5; % feedback text magnification factor
intxt_fac = 1.5; % instruction text magnification factor

% set color opacity
color_rgb   = color_rgb*color_opa+lumibg*(1-color_opa);
color_frame = [96,96,96]/255;

% create video structure
video = [];

try
    
    % hide cursor and stop spilling key presses into MATLAB windows
    HideCursor;
    FlushEvents;
    ListenChar(2);
    
    % check keyboard responsiveness before doing anything
    fprintf('\n');
    fprintf('Press any key to check keyboard responsiveness... ');
    if WaitKeyPress([],10) == 0
        fprintf('\n\n');
        error('No key press detected after 10 seconds.');
    else
        fprintf('Good.\n\n');
    end
    
    % set keys
    KbName('UnifyKeyNames');
    keywait = KbName('space');
    keyquit = KbName('ESCAPE');
    keyresp = KbName({'E','P'});
    
    % open main window
    % set screen resolution and refresh rate
    if ~isempty(res) && ~isempty(fps)
        r = Screen('Resolutions',iscr);
        i = find([r.width] == res(1) & [r.height] == res(2));
        if isempty(i) || ~any([r(i).hz] == fps)
            error('Cannot set screen to %d x %d at %d Hz.',res(1),res(2),fps);
        end
        Screen('Resolution',iscr,res(1),res(2),fps);
    end
    % set screen synchronization properties
    % see 'help SyncTrouble',
    %     'help BeampositionQueries' or
    %     'help ConserveVRAMSettings' for more information
    if syncflip
        if ispc
            % soften synchronization test requirements
            Screen('Preference','SyncTestSettings',[],[],0.2,10);
            % enforce beamposition workaround for missing VBL interval
            Screen('Preference','ConserveVRAM',bitor(4096,Screen('Preference','ConserveVRAM')));
        end
        Screen('Preference','VisualDebuglevel',3);
    else
        % skip synchronization tests altogether
        Screen('Preference','SkipSyncTests',1);
        Screen('Preference','VisualDebuglevel',0);
        Screen('Preference','SuppressAllWarnings',1);
    end
    % set font properties
    if ismac
        txtfnt = 'Helvetica';
        txtsiz = round(1.0*ppd);
    elseif ispc
        txtfnt = 'Arial'; % closest to Helvetica
        txtsiz = round(2/3*ppd); % text size is ~2/3 smaller in Windows than MacOSX
    end
    Screen('Preference','TextAlphaBlending',1);
    Screen('Preference','DefaultFontName',txtfnt);
    Screen('Preference','DefaultFontSize',txtsiz);
    Screen('Preference','DefaultFontStyle',0);
    % prepare configuration and open main window
    PsychImaging('PrepareConfiguration');
    PsychImaging('AddTask','General','UseFastOffscreenWindows');
    PsychImaging('AddTask','General','NormalizedHighresColorRange');
    video.i = iscr;
    video.res = Screen('Resolution',video.i);
    video.h = PsychImaging('OpenWindow',video.i,0);
    [video.x,video.y] = Screen('WindowSize',video.h);
    video.ifi = Screen('GetFlipInterval',video.h,100,50e-6,10);
    Screen('BlendFunction',video.h,GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    Priority(MaxPriority(video.h));
    Screen('ColorRange',video.h,1);
    Screen('FillRect',video.h,lumibg);
    Screen('Flip',video.h);
    
    % check screen refresh rate
    if ~isempty(fps) && fps > 0 && round(1/video.ifi) ~= fps
        error('Screen refresh rate not equal to expected %d Hz.',fps);
    end
    
    % open offscreen window
    video.hoff = Screen('OpenOffscreenWindow',video.h);
    
    % initialize eye-tracker connection
    if trackeye
        if EyelinkInit() ~= 1
            error('could not initialize eye-tracker connection!');
        end
        [~,ev] = Eyelink('GetTrackerVersion');
        fprintf('Connection to %s eye-tracker initialized successfully.\n',ev);
        el = EyelinkInitDefaults(video.h);
        % disable sounds during eye-tracker calibration to avoid nasty conflicts!
        el.targetbeep = 0;
        el.feedbackbeep = 0;
        EyelinkUpdateDefaults(el);
        % update camera setup
        Eyelink('Command','active_eye = LEFT'); % LEFT or RIGHT
        Eyelink('Command','binocular_enabled = NO'); % YES:binocular or NO:monocular
        Eyelink('Command','simulation_screen_distance = 560'); % in mm
        Eyelink('Command','use_ellipse_fitter = NO'); % YES:ellipse or NO:centroid
        Eyelink('Command','pupil_size_diameter = YES'); % YES:diameter or NO:area
        Eyelink('Command','sample_rate = 500'); % 1000 or 500 or 250
        Eyelink('Command','elcl_tt_power = 2'); % 1:100% or 2:75% or 3:50%
        % update calibration parameters
        Eyelink('Command','calibration_type = HV5'); % HV5 or HV9
        Eyelink('Command','generate_default_targets = NO'); % YES:default or NO:custom
        cnt = [video.x/2,video.y/2];
        off = ppd*8;
        pnt = zeros(5,2);
        pnt(1,:) = cnt;
        pnt(2,:) = cnt-[0,off];
        pnt(3,:) = cnt+[0,off];
        pnt(4,:) = cnt-[off,0];
        pnt(5,:) = cnt+[off,0];
        pnt = num2cell(reshape(pnt',[],1));
        Eyelink('Command','calibration_samples = 6');
        Eyelink('Command','calibration_sequence = 0,1,2,3,4,5');
        Eyelink('Command','calibration_targets = %d,%d %d,%d %d,%d %d,%d %d,%d',pnt{:});
        Eyelink('Command','validation_samples = 5');
        Eyelink('Command','validation_sequence = 0,1,2,3,4,5');
        Eyelink('Command','validation_targets = %d,%d %d,%d %d,%d %d,%d %d,%d',pnt{:});
        % update file output parameters
        Eyelink('Command','file_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,MESSAGE');
        Eyelink('Command','file_sample_data = LEFT,RIGHT,GAZE,GAZERES,AREA,STATUS');
    end
    
    % load shape textures
    shape_tex = zeros(2,6); % shape_tex(1,i)=black shape_tex(2,i)=color
    for is = 1:6
        img = double(imread(sprintf('./img/shape%dc.png',is)))/255;
        img = imresize(img,shape_siz/size(img,1));
        shape_tex(1,is) = Screen('MakeTexture',video.h,cat(3,ones(size(img)),img),[],[],2);
        img = double(imread(sprintf('./img/shape%d.png',is)))/255;
        img = imresize(img,shape_siz/size(img,1));
        shape_tex(2,is) = Screen('MakeTexture',video.h,cat(3,ones(size(img)),img),[],[],2);
    end
    shape_rec = zeros(2,4); % shape_rec(1,:)=left shape_rec(2,:)=right
    shape_rec(1,:) = CenterRectOnPoint(Screen('Rect',shape_tex(1,1)),video.x/2-shape_off,video.y/2-shape_off/2);
    shape_rec(2,:) = CenterRectOnPoint(Screen('Rect',shape_tex(1,1)),video.x/2+shape_off,video.y/2-shape_off/2);
    
    % create fixation point
    img = CreateCircularAperture(fixtn_siz);
    fixtn_tex = Screen('MakeTexture',video.h,cat(3,ones(size(img)),img),[],[],2);
    fixtn_rec = CenterRectOnPoint(Screen('Rect',fixtn_tex(1)),video.x/2,video.y/2);
    
    % configure text positioning
    Screen('TextSize',video.hoff,round(txtsiz*fbtxt_fac));
    txtrec = SmallestTextBounds(video.hoff,double('50'));
    txtpos(1,:) = [video.x/2-shape_off,video.y/2+shape_off/2];
    txtpos(2,:) = [video.x/2+shape_off,video.y/2+shape_off/2];
    
    % cpnfigure the rectangles around the text (outcomes)
    txtadd = round(0.2*ppd);
    txtbox = [[video.x/2-shape_off-round(RectWidth(txtrec))*0.67-txtadd;video.y/2+shape_off/2-round(RectWidth(txtrec))*0.50-txtadd;...
               video.x/2-shape_off+round(RectWidth(txtrec))*0.67+txtadd;video.y/2+shape_off/2+round(RectWidth(txtrec))*0.50+txtadd] ...
              [video.x/2+shape_off-round(RectWidth(txtrec))*0.67-txtadd;video.y/2+shape_off/2-round(RectWidth(txtrec))*0.50-txtadd;...
               video.x/2+shape_off+round(RectWidth(txtrec))*0.67+txtadd;video.y/2+shape_off/2+round(RectWidth(txtrec))*0.50+txtadd]];
    
    % first flip
    t = Screen('Flip',video.h);
    
    nblk = length(expe); % total number of blocks
    isprac = cellfun(@(s)strcmp(s,'training'),{expe.type});
    nblk_prac = nnz(isprac); % number of practice blocks
    nblk_expe = nnz(~isprac); % number of experimental blocks
    
    scor_all = nan(nblk,1);
    
    for iblk = 1:nblk %%%
        
        if trackeye && ismember(iblk,[1,nblk_prac+[1,3,5,7]])
            % calibrate eye-tracker
            EyelinkDoTrackerSetup(el,el.ENTER_KEY);
            t = Screen('Flip',video.h);
        end
        
        blck = expe(iblk);
        ntrl = length(blck.vs);
        
        % create results substructure
        rslt       = [];
        rslt.resp  = zeros(ntrl,1); % response as stimulus index
        rslt.rt    = zeros(ntrl,1); % response time (s)
        rslt.rwrd  = zeros(ntrl,1); % obtained reward (relative chosen value)
        
        % create clock substructure
        clck       = [];
        clck.tstim = zeros(ntrl,1); % stimulus pair onset (s)
        clck.tresp = zeros(ntrl,1); % response (s)
        clck.trwrd = zeros(ntrl,1); % reward onset (s)
        
        % draw start screen
        Screen('TextStyle',video.h,0);
        Screen('TextSize',video.h,txtsiz);
        if isprac(iblk)
            labeltxt = 'appuyez sur [espace] pour d�marrer l''entrainement';
            labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt),video.x/2,round(1.2*ppd));
            Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
            Screen('TextSize',video.h,round(txtsiz*intxt_fac));
        else
            labeltxt = sprintf('appuyez sur [espace] pour d�marrer le bloc %d/%d',iblk-nblk_prac,nblk_expe);
            labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt),video.x/2,round(1.2*ppd));
            Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
            Screen('TextSize',video.h,round(txtsiz*intxt_fac));
            if expe(iblk).cfg.tau_samp == 2
                labeltxt_d3 = sprintf('DIFFICULTE faible');
            else
                labeltxt_d3 = sprintf('DIFFICULTE �lev�e');
            end
            labelrec_d3 = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt_d3),video.x/2,video.y/2+round(4*ppd));
            Screen('DrawText',video.h,labeltxt_d3,labelrec_d3(1),labelrec_d3(2),0);
        end
        % instructions for both training & main sessions
        if expe(iblk).cfg.feedback == 2
            labeltxt_d2 = sprintf('RESULTAT complet');
        else
            labeltxt_d2 = sprintf('RESULTAT partiel');
        end
        if expe(iblk).cfg.anticorr == 1
            labeltxt_d1 = sprintf('MACHINES connect�es');
        else
            labeltxt_d1 = sprintf('MACHINES ind�pendantes');
        end
        if isprac(iblk)
            labelrec_d1 = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt_d1),video.x/2,video.y/2-round(2*ppd));
            labelrec_d2 = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt_d2),video.x/2,video.y/2+round(2*ppd));
        else
            labelrec_d1 = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt_d1),video.x/2,video.y/2-round(4*ppd));
            labelrec_d2 = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt_d2),video.x/2,video.y/2);
        end
        Screen('DrawText',video.h,labeltxt_d1,labelrec_d1(1),labelrec_d1(2),0);
        Screen('DrawText',video.h,labeltxt_d2,labelrec_d2(1),labelrec_d2(2),0);
        Screen('DrawingFinished',video.h);
        Screen('Flip',video.h,t+roundfp(2.000,0.500));
        WaitKeyPress(keywait);
        
        % draw fixation point
        Screen('DrawTexture',video.h,fixtn_tex,[],fixtn_rec,[],[],[],0);
        Screen('DrawingFinished',video.h);
        t = Screen('Flip',video.h);
        t0 = t;
        
        if trackeye
            % start recording
            Eyelink('OpenFile','RLVAR');
            Eyelink('StartRecording');
            eye_used = Eyelink('EyeAvailable');
            if ~isprac(iblk)
                % wait for 10 extra seconds
                Screen('DrawTexture',video.h,fixtn_tex,[],fixtn_rec,[],[],[],0);
                Screen('DrawingFinished',video.h);
                t = Screen('Flip',video.h,t+roundfp(10.000));
            end
        end

        for itrl = 1:ntrl
            
            % check if abort key is pressed
            if CheckKeyPress(keyquit)
                aborted = true;
                break
            end
            
            il = 1+(blck.pos(itrl) == 2); % stimulus index at left position
            ir = 3-il; % stimulus index at right position
            
            % draw stimuli
            draw_stim;
            % draw fixation point
            Screen('DrawTexture',video.h,fixtn_tex,[],fixtn_rec,[],[],[],0);
            % draw the two rectangles around the places where outcomes will appear 
            Screen('FrameRect',video.h,color_frame,txtbox,8);
            Screen('DrawingFinished',video.h);
            
            t = Screen('Flip',video.h,t+roundfp(2.000,0.500));
            clck.tstim(itrl) = t-t0;
            if trackeye
                eyemess = sprintf('TRL%03d_STIM',itrl);
                Eyelink('Message',eyemess);
            end
            [key,tkey] = WaitKeyPress(keyresp,[],false);
            if key == 1
                rslt.resp(itrl) = il;
            else
                rslt.resp(itrl) = ir;
            end
            rslt.rt(itrl) = tkey-t;
            if key == 1
                rslt.rwrd(itrl) = blck.vm(il,itrl)-blck.vm(ir,itrl);
            else
                rslt.rwrd(itrl) = blck.vm(ir,itrl)-blck.vm(il,itrl);
            end
            if trackeye
                eyemess = sprintf('TRL%03d_RESP',itrl);
                Eyelink('Message',eyemess);
            end
            % draw stimuli
            draw_stim;
            Screen('DrawTexture',video.h,fixtn_tex,[],fixtn_rec,[],[],[],0);
            %  draw frames 
            Screen('FrameRect',video.h,color_frame,txtbox,8);
            Screen('DrawingFinished',video.h);
            t = Screen('Flip',video.h);
            clck.tresp(itrl) = tkey-t0;
            
            % draw stimuli
            draw_stim;
            Screen('DrawTexture',video.h,fixtn_tex,[],fixtn_rec,[],[],[],0);
            % draw frames 
            Screen('FrameRect',video.h,color_frame,txtbox,8);
            % draw left feedback
            if key == 1  || blck.cfg.feedback == 2
                labeltxt = num2str(blck.vs(il,itrl),'%02d');
            else
                labeltxt = '??';
            end
            Screen('TextSize',video.h,round(txtsiz*fbtxt_fac));
            txtbnd = Screen('TextBounds',video.h,labeltxt);
            xoff = round(0.5*( ...
                txtbnd(RectRight)-txtrec(RectRight)+ ...
                txtbnd(RectLeft)-txtrec(RectLeft)));
            yoff = round(0.5*( ...
                txtbnd(RectBottom)-txtrec(RectBottom)+ ...
                txtbnd(RectTop)-txtrec(RectTop)));
            labelrec = CenterRectOnPoint(txtbnd,txtpos(1,1)+xoff,txtpos(1,2)+yoff);
            Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
            % draw right feedback
            if key == 2 || blck.cfg.feedback == 2
                labeltxt = num2str(blck.vs(ir,itrl),'%02d');
            else
                labeltxt = '??';
            end
            Screen('TextSize',video.h,round(txtsiz*fbtxt_fac));
            txtbnd = Screen('TextBounds',video.h,labeltxt);
            xoff = round(0.5*( ...
                txtbnd(RectRight)-txtrec(RectRight)+ ...
                txtbnd(RectLeft)-txtrec(RectLeft)));
            yoff = round(0.5*( ...
                txtbnd(RectBottom)-txtrec(RectBottom)+ ...
                txtbnd(RectTop)-txtrec(RectTop)));
            labelrec = CenterRectOnPoint(txtbnd,txtpos(2,1)+xoff,txtpos(2,2)+yoff);
            Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
            Screen('DrawingFinished',video.h);
            t = Screen('Flip',video.h,t+roundfp(0.500));
            clck.trwrd(itrl) = t-t0;
            if trackeye
                eyemess = sprintf('TRL%03d_RWRD',itrl);
                Eyelink('Message',eyemess);
            end
            
            % draw fixation point
            Screen('DrawTexture',video.h,fixtn_tex,[],fixtn_rec,[],[],[],0);
            Screen('DrawingFinished',video.h);
            t = Screen('Flip',video.h,t+roundfp(1.000));
            
        end % end trial loop 
        
        % store results and clock substructures
        expe(iblk).rslt = [];
        expe(iblk).clck = [];
        expe(iblk).rslt = rslt;
        expe(iblk).clck = clck;
        
        if trackeye
            if ~isprac(iblk)
                % wait for 10 extra seconds
                Screen('DrawTexture',video.h,fixtn_tex,[],fixtn_rec,[],[],[],0);
                Screen('DrawingFinished',video.h);
                Screen('Flip',video.h,t+roundfp(10.000));
            end
            % stop recording
            Eyelink('StopRecording');
            Eyelink('CloseFile');
            % retrieve eye-tracker datafile
            if ~aborted
                fpath = sprintf('./Data/S%02d',hdr.subj);
                fname = sprintf('RLVAR_S%02d_b%02d_%s',hdr.subj,iblk,datestr(now,'yyyymmdd-HHMM'));
                fname = fullfile(fpath,fname);
                for i = 1:10
                    status = Eyelink('ReceiveFile',[],[fname,'.edf']);
                    if status >= 0 % should be >
                        break
                    end
                end
                if status < 0 % should be <=
                    warning('could not retrieve eye-tracker datafile %s!',fname);
                else
                    save([fname,'.mat'],'expe');
                end
            end
            % redraw fixation point
            Screen('DrawTexture',video.h,fixtn_tex,[],fixtn_rec,[],[],[],0);
            Screen('DrawingFinished',video.h);
            t = Screen('Flip',video.h);
        end

        if aborted
            break
        end

        if ~isprac(iblk)
            % draw score screen
            Screen('TextStyle',video.h,0);
            Screen('TextSize',video.h,txtsiz);
            labeltxt = 'appuyez sur [espace]';
            labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt),video.x/2,round(1.2*ppd));
            Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
            Screen('TextSize',video.h,round(txtsiz*fbtxt_fac));
            out = sim_model_ref(expe,iblk,rslt.resp(1));
            srel = mean(rslt.rwrd)/out.s_vm;
            if srel < 0.50
                scor = 0;
            elseif srel < 0.75
                scor = 5;
            else
                scor = 10;
            end
            scor_all(iblk) = scor;
            labeltxt = [double(sprintf('bonus sur ce bloc : %d ',scor)),8364];
            labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt),video.x/2,video.y/2);
            Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
        else
            % plot mean reaction time
            Screen('TextStyle',video.h,0);
            Screen('TextSize',video.h,txtsiz);
            labeltxt = 'appuyez sur [espace]';
            labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt),video.x/2,round(1.2*ppd));
            Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
            labeltxt = sprintf('temps de r�ponse : %.0f ms',mean(rslt.rt)*1000);
            labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt),video.x/2,video.y/2);
            Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
        end
        Screen('DrawingFinished',video.h);
        Screen('Flip',video.h,t+roundfp(2.000,0.500));
        WaitKeyPress(keywait);
        t = Screen('Flip',video.h);

    end
    
    if ~aborted
        % compute final score
        scor_avg = nanmean(scor);
        if any(scor == ceil(scor_avg/5)*5)
            scor_fin = ceil(scor_avg/5)*5;
        else
            scor_fin = floor(scor_avg/5)*5;
        end
        Screen('TextSize',video.h,round(txtsiz*fbtxt_fac));
        labeltxt = [double(sprintf('votre bonus : %d ',scor_fin)),8364];
        labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,labeltxt),video.x/2,video.y/2);
        Screen('DrawText',video.h,labeltxt,labelrec(1),labelrec(2),0);
        Screen('DrawingFinished',video.h);
        Screen('Flip',video.h,t+roundfp(2.000,0.500));
        WaitKeyPress(keywait);
        Screen('Flip',video.h);
    end

    if trackeye
        % reset to default calibration targets
        Eyelink('Command','generate_default_targets = YES');
        % close eye-tracker connection
        Eyelink('Shutdown');
    end
    
    % close Psychtoolbox
    Priority(0);
    Screen('CloseAll');
    FlushEvents;
    ListenChar(0);
    ShowCursor;
    
catch
    
    if trackeye && exist('el','var')
        % stop recording
        Eyelink('StopRecording');
        % reset to default calibration targets
        Eyelink('Command','generate_default_targets = YES');
        % close eye-tracker connection
        Eyelink('Shutdown');
    end
    
    % close Psychtoolbox
    Priority(0);
    Screen('CloseAll');
    FlushEvents;
    ListenChar(0);
    ShowCursor;
    
    % handle error
    if nargout > 2
        errmsg = lasterror;
        errmsg = rmfield(errmsg,'stack');
    else
        rethrow(lasterror);
    end
    
end

    function [t] = roundfp(t,dt)
        % apply duration rounding policy for video flips
        % where t  - desired (input)/rounded (output) duration
        %       dt - desired uniform jitter on duration (default: none)
        n = round(t/video.ifi);
        % apply uniform jitter
        if nargin > 1 && dt > 0
            m = round(dt/video.ifi);
            n = n+ceil((m*2+1)*rand)-(m+1);
        end
        % convert frames to duration
        t = (n-0.5)*video.ifi;
    end
    
    function [x] = bit2dec(b)
        % convert binary array to decimal
        x = sum(b(:).*2.^(0:numel(b)-1)');
    end

    function draw_stim
        % draw left stimulus
        is = blck.shape(il);
        ic = blck.color(il);
        Screen('DrawTexture',video.h,shape_tex(1,is),[],shape_rec(1,:),[],[],[],0);
        Screen('DrawTexture',video.h,shape_tex(2,is),[],shape_rec(1,:),[],[],[],color_rgb(ic,:));
        % draw right stimulus
        is = blck.shape(ir);
        ic = blck.color(ir);
        Screen('DrawTexture',video.h,shape_tex(1,is),[],shape_rec(2,:),[],[],[],0);
        Screen('DrawTexture',video.h,shape_tex(2,is),[],shape_rec(2,:),[],[],[],color_rgb(ic,:));
    end

end