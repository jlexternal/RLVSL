%%
clear all java
close all hidden
clc

% add toolboxes
addpath ./Toolboxes/Rand/
addpath ./Toolboxes/Stimuli/Visual/
addpath ./Toolboxes/IO/

% get participant information
argindlg = inputdlg({'Subject number'},'RLVAR',1,{'','','','',''});
if isempty(argindlg)
    error('experiment cancelled!');
end
subj = str2num(argindlg{1});

% run experiment
[expe,aborted] = run_expe(subj,true,true);

if ~aborted
    % save data to disk
    filename = sprintf('./Data/S%02d/RLVAR_S%02d_%s.mat',expe(1).hdr.subj,expe(1).hdr.subj,expe(1).hdr.date);
    save(filename,'expe');
end
